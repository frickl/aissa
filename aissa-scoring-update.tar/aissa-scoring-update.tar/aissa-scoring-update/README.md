# AISSA scoring update for the existing manta installation

This is an incremental update for the bridge/Lua version supplied on 2026-10-02.
It does not contain or replace analyzer.py, service.py, credentials or systemd
configuration. The Lua file is based on the uploaded active file; the Python
bridge is based on the pasted bridge.py. See docs/aissa-scoring.md for behavior,
weights, checks, and limits.

On the server, place this archive in /opt and extract it:

```bash
cd /opt
tar -xzf aissa-scoring-update.tar.gz
cd aissa-scoring-update
bash install.sh
```

The installer backs up changed source/config/README files, installs code/tests,
adds a scoring-document link to the existing project README, sets selection to
100%, enables scoring with a 10-second budget, adds the scores include, and runs
Python tests and rspamadm configtest. It does not restart either service. If tests
or configtest fail, it restores the files it changed. Existing custom scores are
preserved on repeated installation.

Before activation, ensure the overall task_timeout of actual rspamd scanner
workers (including the controller used by rspamc) is at least 20s. Inspect:

```bash
rspamadm configdump | grep -E 'worker|task_timeout|self_scan'
```

Set `task_timeout = 20s;` in the applicable local.d/worker-*.inc files; then:

```bash
rspamadm configtest
# Restart only after the old bridge reports outstanding=0.
systemctl restart aissa
systemctl reload rspamd
cd /opt/aissa
rspamc -t 30 -p < samples/phish-fr.eml
```

A bridge restart clears its RAM queue/results. Avoid restarting with outstanding
jobs if their retention matters. No model/service timeout changes are needed for
this live scoring extension.

Default points: phishing +3, spam +1, bulk/ham/uncertain 0. Tune weights in
/etc/rspamd/local.d/aissa-scores.conf and reload rspamd. Switch back to observation
by setting scoring_enabled=false in local.d/aissa.conf and reloading rspamd.

Project source copies are updated as well. Review and commit the source/tests/docs
in /opt/aissa to Git; never commit credentials, the generated backup, or local
server configuration containing passwords. No Git push is performed here.
