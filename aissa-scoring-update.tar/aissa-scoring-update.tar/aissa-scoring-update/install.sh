#!/bin/bash
set -Eeuo pipefail
[ "$(id -u)" -eq 0 ] || { echo 'Run as root on manta.'; exit 1; }
package_dir=$(cd -- "$(dirname -- "$0")" && pwd)
project_dir=/opt/aissa
rspamd_dir=/etc/rspamd/local.d
[ -f "$project_dir/aissa/service.py" ]
[ -f "$project_dir/aissa/bridge.py" ]
[ -f "$rspamd_dir/aissa.lua" ]
[ -f "$rspamd_dir/aissa.conf" ]
[ -f "$project_dir/README.md" ]
command -v rspamadm >/dev/null
backup_dir=$(mktemp -d "$project_dir/.aissa-scoring-backup-XXXXXXXX")
chmod 0700 "$backup_dir"
source_files=(aissa/bridge.py rspamd/aissa.lua rspamd/aissa-scores.conf
  tests/test_bridge_scoring.py tests/test_lua_scoring.py
  tests/aissa_scoring_harness.lua docs/aissa-scoring.md)
changed_files=("$project_dir/README.md" "$rspamd_dir/aissa.lua"
  "$rspamd_dir/aissa.conf" "$rspamd_dir/aissa-scores.conf"
  "$project_dir/rspamd/aissa.conf")
for file in "${source_files[@]}"; do changed_files+=("$project_dir/$file"); done
for file in "${changed_files[@]}"; do
  if [ -e "$file" ]; then cp -a --parents -- "$file" "$backup_dir/"; fi
done
rollback() {
  trap - ERR INT TERM
  for file in "${changed_files[@]}"; do
    saved="$backup_dir/${file#/}"
    if [ -e "$saved" ]; then cp -a -- "$saved" "$file"; else rm -f -- "$file"; fi
  done
  echo "Update failed; changed files restored. Backup: $backup_dir" >&2
  exit 1
}
trap rollback ERR INT TERM
for file in "${source_files[@]}"; do
  mkdir -p -- "$(dirname -- "$project_dir/$file")"
  install -m 0644 -- "$package_dir/$file" "$project_dir/$file"
done
install -m 0644 -- "$package_dir/rspamd/aissa.lua" "$rspamd_dir/aissa.lua"
if [ ! -f "$rspamd_dir/aissa-scores.conf" ]; then
  install -m 0644 -- "$package_dir/rspamd/aissa-scores.conf" "$rspamd_dir/aissa-scores.conf"
fi
python3 - <<'PY'
from pathlib import Path
import re
p=Path('/etc/rspamd/local.d/aissa.conf')
s=p.read_text()
for key, value in [('sample_percent','100'), ('scoring_enabled','true'), ('score_wait_seconds','10')]:
    # Only plain, top-level single-line assignments are rewritten.
    pattern = rf'(?m)^{key}\s*=\s*[^;\n]+;[^\n]*$'
    if re.search(pattern,s):
        s=re.sub(pattern,f'{key} = {value};',s)
    elif re.search(rf'(?m)^\s*{key}\s*=',s):
        raise ValueError('Please normalize '+key+' to a top-level single-line assignment first')
    else:
        s=s.rstrip()+'\n'+f'{key} = {value};\n'
if 'aissa-scores.conf' not in s:
    s=s.rstrip()+'\n.include "$LOCAL_CONFDIR/local.d/aissa-scores.conf"\n'
p.write_text(s)
Path('/opt/aissa/rspamd/aissa.conf').write_text(s)
Path('/opt/aissa/rspamd/aissa-scores.conf').write_text(Path('/etc/rspamd/local.d/aissa-scores.conf').read_text())
p=Path('/opt/aissa/README.md')
s=p.read_text()
if 'docs/aissa-scoring.md' not in s:
    s += '\n\n## Live scoring extension\n\nSee [AISSA live scoring](docs/aissa-scoring.md) for the current bridge/Lua\nflow, configurable points, bounded scan wait, Redis collection and limitations.\nThis supersedes earlier observe-only integration instructions when enabled.\n'
p.write_text(s)
PY
cd "$project_dir"
python3 -m unittest discover -s tests -v
rspamadm configtest
trap - ERR INT TERM
printf 'Installed and checked. Backup: %s\n' "$backup_dir"
printf '%s\n' 'No services restarted. Configure worker task_timeout >=20s; then follow README.md in the update package to activate.'
