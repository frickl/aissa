# AISSA prompt/evaluation update

For the existing `/opt/aissa` installation on manta. The package contains a
compact classification rubric, 25 labeled synthetic evaluation messages, an
offline before/after evaluator, tests, and a targeted installer.

Place the archive in /opt, then:

```bash
cd /opt
tar -xzf aissa-prompt-update.tar.gz
cd aissa-prompt-update
python3 install.py
cd /opt/aissa
python3 -m aissa.evaluate evaluation/manifest.json --prompt previous --timeout 120 --output evaluation-before.jsonl
python3 -m aissa.evaluate evaluation/manifest.json --prompt current --timeout 120 --output evaluation-after.jsonl
tail -n 1 evaluation-before.jsonl
tail -n 1 evaluation-after.jsonl
```

The installer backs up files, replaces only SYSTEM in the deployed analyzer with
an import, saves the old prompt, installs evaluator/test fixtures, updates the
project README link and runs Python tests. It preserves local analyzer fixes and
does not change Redis, Lua, model options, score weights, or service configuration.
On installation/test failure it restores changed files. It does not restart services.

Evaluate offline first: the running bridge keeps the old prompt until restarted.
Only if the measured classifications are better, restart aissa when outstanding=0.
Share the two final summary lines and any mismatched case rows for further work.
Results come from the model on your server, not from unit-test mocks.

See docs/aissa-evaluation.md for interpretation, limitations and rollback.
