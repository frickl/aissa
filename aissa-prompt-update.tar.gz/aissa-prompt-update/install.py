#!/usr/bin/env python3
"""Patch only the current SYSTEM assignment; preserve the deployed analyzer."""
import ast
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time


def main():
    if os.geteuid() != 0:
        raise SystemExit('Run as root on manta.')
    root = Path('/opt/aissa')
    package = Path(__file__).resolve().parent
    analyzer = root / 'aissa/analyzer.py'
    old = analyzer.read_text()
    tree = ast.parse(old)
    assignments = [node for node in tree.body if isinstance(node, ast.Assign)
                   and any(isinstance(target, ast.Name) and target.id == 'SYSTEM'
                           for target in node.targets)]
    imported = any(isinstance(node, ast.ImportFrom) and node.level == 1
                   and node.module == 'prompt'
                   and any(alias.name == 'SYSTEM' for alias in node.names)
                   for node in tree.body)
    if len(assignments) == 1 and not imported:
        node = assignments[0]
        lines = old.splitlines(keepends=True)
        if node.col_offset != 0:
            raise SystemExit('Unexpected SYSTEM assignment; no files changed.')
        updated = ''.join(lines[:node.lineno-1]) + 'from .prompt import SYSTEM\n' + ''.join(lines[node.end_lineno:])
    elif not assignments and imported:
        updated = old
    else:
        raise SystemExit('Cannot identify SYSTEM safely; no files changed.')
    compile(updated, str(analyzer), 'exec')
    previous = root/'evaluation/previous_prompt.txt'
    previous_text = None
    if not previous.exists():
        if assignments:
            previous_text = ast.literal_eval(assignments[0].value)
        else:
            prompt_tree = ast.parse((root/'aissa/prompt.py').read_text())
            prompt_nodes = [node for node in prompt_tree.body if isinstance(node, ast.Assign)
                            and any(isinstance(target, ast.Name) and target.id == 'SYSTEM'
                                    for target in node.targets)]
            if len(prompt_nodes) != 1:
                raise SystemExit('Cannot preserve previous prompt; no files changed.')
            previous_text = ast.literal_eval(prompt_nodes[0].value)
        if not isinstance(previous_text, str):
            raise SystemExit('SYSTEM is not a literal string; no files changed.')
    paths = ['aissa/prompt.py', 'aissa/evaluate.py', 'tests/test_evaluate.py',
             'evaluation/manifest.json', 'docs/aissa-evaluation.md']
    paths += ['evaluation/' + str(p.relative_to(package/'evaluation'))
              for p in sorted((package/'evaluation').glob('*/*.eml'))]
    changed = ['aissa/analyzer.py', 'README.md', 'evaluation/previous_prompt.txt'] + paths
    backup = root / ('.aissa-prompt-backup-' + str(time.time_ns()))
    backup.mkdir(mode=0o700)
    existing = set()
    for relative in changed:
        dest = root/relative
        if dest.exists():
            existing.add(relative)
            saved = backup/relative
            saved.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(dest, saved)
    try:
        analyzer.write_text(updated)
        if previous_text is not None:
            previous.parent.mkdir(parents=True, exist_ok=True)
            previous.write_text(previous_text)
            previous.chmod(0o644)
        for relative in paths:
            dest = root/relative
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(package/relative, dest)
            dest.chmod(0o644)
        readme = root/'README.md'
        text = readme.read_text()
        if 'docs/aissa-evaluation.md' not in text:
            readme.write_text(text + '\n\n## Classifier evaluation\n\nSee [classifier evaluation](docs/aissa-evaluation.md) for the prompt rubric,\nsynthetic evaluation cases, expected labels, benchmark commands and limitations.\n')
        subprocess.run([sys.executable, '-m', 'unittest', 'discover', '-s', 'tests', '-v'], cwd=root, check=True)
    except BaseException:
        for relative in changed:
            dest = root/relative
            if relative in existing:
                shutil.copy2(backup/relative, dest)
            else:
                dest.unlink(missing_ok=True)
        raise
    print('Prompt and evaluator installed. Backup:', backup)
    print('No services restarted. Evaluate offline first; then restart aissa when outstanding=0.')


if __name__ == '__main__':
    main()
